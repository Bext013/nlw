import { Widget } from "./components/Widget";

export function App() {
  return (
    <div>
      <Widget />
    </div>
  );
}
